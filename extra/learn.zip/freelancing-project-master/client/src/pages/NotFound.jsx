import { Container } from "@mui/material";
import React from "react";

function NotFound() {
  return <Container>Page Not Found</Container>;
}

export default NotFound;
