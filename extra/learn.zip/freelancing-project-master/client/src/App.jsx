import React, { useContext } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import Loader from "./components/Loader";
import { AuthContext } from "./context";
import CreateForm from "./pages/CreateForm";
import CreateUser from "./pages/CreateUser";
import ListForm from "./pages/ListForm";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Signup from "./pages/Signup";

function Protected({ children, isAuthenticated }) {
  if (!isAuthenticated) return <Navigate to="/" replace />;

  return children;
}

const routes = {
  admin: [
    {
      path: "/listForm",
      element: <ListForm />,
    },
    {
      path: "/createForm",
      element: <CreateForm />,
    },
    {
      path: "/createUser",
      element: <CreateUser />,
    },
  ],
  reccee: [
    {
      path: "/createForm",
      element: <CreateForm />,
    },
  ],
};

function App() {
  const { isAuthenticated, loading, user } = useContext(AuthContext);

  if (loading)
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Loader />
      </div>
    );

  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        {user?.role &&
          routes[user?.role].map((e, i) => (
            <Route
              key={i}
              path={e.path}
              element={
                <Protected isAuthenticated={isAuthenticated}>
                  {e.element}
                </Protected>
              }
            />
          ))}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default App;
